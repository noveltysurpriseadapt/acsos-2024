package rdm.management;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import rdm.gui.GraphGUI;
import rdm.network.Monitorables;

import rdm.network.TopologyList;

public class RDMSimulator extends Application{
	
	
	public static void main(String args[])
	{
		//Step1:Create an object of NetworkManagement to load the simulation and network properties from configuration file
		NetworkManagment nm=new NetworkManagment();
		
		//Step: 2 Instantiate the probe and effector
		Probe probe=nm.getProbe();
		Effector effector=nm.getEffector();
		
		
	     for(int timestep=0;timestep<nm.simulation_properties.getSimulationRuns();timestep++) {
			
			//Monitor
			Monitorables m=probe.getMonitorables();
			
			//Analyse and Plan
						
			if (probe.getActiveLinks()<m.getThresholdActiveLinks()&&probe.getBandwidthConsumption()>m.getThresholdBandwidthConsumption()||probe.getTimeToWrite()>m.getThresholdTimeToWrite())
			{
				int random_topology=(int)ThreadLocalRandom.current().nextDouble(0,TopologyList.topologies.size());
				effector.setNetworkTopology(timestep,TopologyList.topologies.get(random_topology).getTopologyName());

				//effector.setNetworkTopology(timestep,"mst");
				//System.out.println("mst");
				
			}
			else if(probe.getActiveLinks()>m.getThresholdActiveLinks()&&probe.getBandwidthConsumption()<m.getThresholdBandwidthConsumption()||probe.getTimeToWrite()<m.getThresholdTimeToWrite())
			{
				int random_topology=(int)ThreadLocalRandom.current().nextDouble(0,TopologyList.topologies.size());
				//execute
				effector.setNetworkTopology(timestep,TopologyList.topologies.get(random_topology).getTopologyName());

				//effector.setNetworkTopology(timestep,"mst");
				//System.out.println("rt");
				
			}
			else
			{
				int random_topology=(int)ThreadLocalRandom.current().nextDouble(0,TopologyList.topologies.size());

				effector.setNetworkTopology(timestep,TopologyList.topologies.get(random_topology).getTopologyName());
				//System.out.println("mst");
			}
				
		
	}
	//System.exit(0);
	     displayResults(args);
		
		

	}

	public static void displayResults(String args[])
	{
		launch(args);
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		
		
		//GUI g=new GUI();
		GraphGUI g=new GraphGUI();
		Scene scene=new Scene(g,1000,500);
		stage.setScene(scene);	
		stage.setTitle("RDMSim");
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		stage.setHeight(screenSize.getHeight()-50);
		stage.setWidth(screenSize.getWidth());
		//stage.setMaximized(true);
		stage.show();
	}
	
	
	///new code
	@Override
    public void stop() throws Exception {
        super.stop();
        GraphGUI.scheduledExecutorService.shutdownNow();
    }
	
}
