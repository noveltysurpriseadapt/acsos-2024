package rdm.management;

import rdm.network.Monitorables;
import rdm.network.Topology;


public interface Probe {
	
	public Topology getCurrentTopology();
	public int getBandwidthConsumption();
	public int getActiveLinks();
	public int getTimeToWrite();
	public Monitorables getMonitorables();
	
	

}
