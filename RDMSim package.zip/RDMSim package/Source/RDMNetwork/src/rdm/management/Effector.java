package rdm.management;

import rdm.network.Topology;

public interface Effector {
	
	
	public void setNetworkTopology(int simulation_timestep,String selected_topology);
	public void setActiveLinks(int active_links);
	public void setBandwidthConsumption(double bandwidth_consumption);
	public void setTimeToWrite(double time_to_write);
	public void setCurrentTopology(Topology current_topology);
	

}
