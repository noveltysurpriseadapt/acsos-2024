package rdm.simulation;

import java.util.concurrent.ThreadLocalRandom;

public class UncertaintyScenario {
	
	private int current_scenario;
	private int min_deviation_mst_links;
	private int max_deviation_mst_links;	
	private int min_deviation_rt_links;	
	private int max_deviation_rt_links;
	
	private int min_deviation_mst_bandwidth;
	private int max_deviation_mst_bandwidth;	
	private int min_deviation_rt_bandwidth;
	private int max_deviation_rt_bandwidth;
	
	private int min_deviation_mst_writing_time;
	private int max_deviation_mst_writing_time;	
	private int min_deviation_rt_writing_time;
	private int max_deviation_rt_writing_time;
	
	
	
	public UncertaintyScenario() {
		// TODO Auto-generated constructor stub
		current_scenario=0;
	}

	public int getCurrentScenario() {
		return current_scenario;
	}

	public void setCurrentScenario(int current_scenario) {
		this.current_scenario = current_scenario;
	}
	
	
	public int getMinDeviationMSTLinks() {
		return min_deviation_mst_links;
	}

	public void setMinDeviationMSTLinks(int min_deviation_mst_links) {
		this.min_deviation_mst_links = min_deviation_mst_links;
	}

	public int getMaxDeviationMSTLinks() {
		return max_deviation_mst_links;
	}

	public void setMaxDeviationMSTLinks(int max_deviation_mst_links) {
		this.max_deviation_mst_links = max_deviation_mst_links;
	}

	public int getMinDeviationRTLinks() {
		return min_deviation_rt_links;
	}

	public void setMinDeviationRTLinks(int min_deviation_rt_links) {
		this.min_deviation_rt_links = min_deviation_rt_links;
	}

	public int getMaxDeviationRTLinks() {
		return max_deviation_rt_links;
	}

	public void setMaxDeviationRTLinks(int max_deviation_rt_links) {
		this.max_deviation_rt_links = max_deviation_rt_links;
	}

	public int getMinDeviationMSTBandwidth() {
		return min_deviation_mst_bandwidth;
	}

	public void setMinDeviationMSTBandwidth(int min_deviation_mst_bandwidth) {
		this.min_deviation_mst_bandwidth = min_deviation_mst_bandwidth;
	}

	public int getMaxDeviationMSTBandwidth() {
		return max_deviation_mst_bandwidth;
	}

	public void setMaxDeviationMSTBandwidth(int max_deviation_mst_bandwidth) {
		this.max_deviation_mst_bandwidth = max_deviation_mst_bandwidth;
	}

	public int getMinDeviationRTBandwidth() {
		return min_deviation_rt_bandwidth;
	}

	public void setMinDeviationRTBandwidth(int min_deviation_rt_bandwidth) {
		this.min_deviation_rt_bandwidth = min_deviation_rt_bandwidth;
	}

	public int getMaxDeviationRTBandwidth() {
		return max_deviation_rt_bandwidth;
	}

	public void setMaxDeviationRTBandwidth(int max_deviation_rt_bandwidth) {
		this.max_deviation_rt_bandwidth = max_deviation_rt_bandwidth;
	}

	public int getMinDeviationMSTWritingTime() {
		return min_deviation_mst_writing_time;
	}

	public void setMinDeviationMSTWritingTime(int min_deviation_mst_writing_time) {
		this.min_deviation_mst_writing_time = min_deviation_mst_writing_time;
	}

	public int getMaxDeviationMSTWritingTime() {
		return max_deviation_mst_writing_time;
	}

	public void setMaxDeviationMSTWritingTime(int max_deviation_mst_writing_time) {
		this.max_deviation_mst_writing_time = max_deviation_mst_writing_time;
	}

	public int getMinDeviationRTWritingTime() {
		return min_deviation_rt_writing_time;
	}

	public void setMinDeviationRTWritingTime(int min_deviation_rt_writing_time) {
		this.min_deviation_rt_writing_time = min_deviation_rt_writing_time;
	}

	public int getMaxDeviationRTWritingTime() {
		return max_deviation_rt_writing_time;
	}

	public void setMaxDeviationRTWritingTime(int max_deviation_rt_writing_time) {
		this.max_deviation_rt_writing_time = max_deviation_rt_writing_time;
	}

	
	
}
