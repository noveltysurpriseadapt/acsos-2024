package rdm.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class ConfigurationSettings extends JFrame {

	private JPanel contentPane;
	private JTextField txtnetworklinks;
	private JTextField txtMirrorNumbers;
	private JTextField txtBandwidthConsumption;
	private JTextField txtActiveLinks;
	private JTextField txtTimetoWrite;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConfigurationSettings frame = new ConfigurationSettings();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ConfigurationSettings() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 430, 521);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblMirrorNumbers = new JLabel("Number of Mirrors");
		lblMirrorNumbers.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblMirrorNumbers.setBounds(25, 69, 148, 27);
		contentPane.add(lblMirrorNumbers);
		
		txtnetworklinks = new JTextField();
		txtnetworklinks.setEditable(false);
		txtnetworklinks.setBounds(195, 108, 201, 26);
		contentPane.add(txtnetworklinks);
		txtnetworklinks.setColumns(10);
				
		JLabel lblNetworkLinks = new JLabel("Network Links");
		lblNetworkLinks.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNetworkLinks.setBounds(25, 108, 148, 27);
		contentPane.add(lblNetworkLinks);
		
		txtMirrorNumbers = new JTextField();
		txtMirrorNumbers.setColumns(10);
		txtMirrorNumbers.setBounds(195, 69, 201, 26);
		contentPane.add(txtMirrorNumbers);
		
		JLabel lblUncertaintyScenario = new JLabel("Uncertainty Scenario");
		lblUncertaintyScenario.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblUncertaintyScenario.setBounds(25, 148, 183, 27);
		contentPane.add(lblUncertaintyScenario);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(195, 148, 201, 26);
		contentPane.add(comboBox);
		comboBox.addItem("Stable_Scenario");
		comboBox.addItem("Detrimental_Scenario_1");
		comboBox.addItem("Detrimental_Scenario_2");
		comboBox.addItem("Detrimental_Scenario_3");
		comboBox.addItem("Detrimental_Scenario_4");
		comboBox.addItem("Detrimental_Scenario_5");
		comboBox.addItem("Detrimental_Scenario_6");
		
		JLabel lblUncertaintyScenario_1 = new JLabel("Satisfaction Thresholds");
		lblUncertaintyScenario_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblUncertaintyScenario_1.setBounds(127, 215, 210, 27);
		contentPane.add(lblUncertaintyScenario_1);
		
		JLabel lblBandwidthConsumption = new JLabel("Bandwidth Consumption");
		lblBandwidthConsumption.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblBandwidthConsumption.setBounds(15, 261, 226, 27);
		contentPane.add(lblBandwidthConsumption);
		
		txtBandwidthConsumption = new JTextField();
		txtBandwidthConsumption.setColumns(10);
		txtBandwidthConsumption.setBounds(195, 262, 201, 26);
		contentPane.add(txtBandwidthConsumption);
		
		JLabel lblActiveLinks = new JLabel("Active Network Links");
		lblActiveLinks.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblActiveLinks.setBounds(15, 299, 226, 27);
		contentPane.add(lblActiveLinks);
		
		txtActiveLinks = new JTextField();
		txtActiveLinks.setColumns(10);
		txtActiveLinks.setBounds(195, 300, 201, 26);
		contentPane.add(txtActiveLinks);
		
		JLabel lblTimeToWrite = new JLabel("Time To Write Data");
		lblTimeToWrite.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTimeToWrite.setBounds(15, 334, 226, 27);
		contentPane.add(lblTimeToWrite);
		
		txtTimetoWrite = new JTextField();
		txtTimetoWrite.setColumns(10);
		txtTimetoWrite.setBounds(195, 335, 201, 26);
		contentPane.add(txtTimetoWrite);
		
		txtMirrorNumbers.setEditable(false);
		txtActiveLinks.setEditable(false);
		txtBandwidthConsumption.setEditable(false);
		txtTimetoWrite.setEditable(false);
		
		
		JLabel lblConfigurationSettings = new JLabel("Configuration Settings");
		lblConfigurationSettings.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblConfigurationSettings.setBounds(125, 16, 249, 32);
		contentPane.add(lblConfigurationSettings);
		
		JButton btnSave = new JButton("Save");
		btnSave.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnSave.setBounds(298, 386, 97, 27);
		btnSave.setEnabled(false);
		contentPane.add(btnSave);
		
		JButton btnRunSimulation = new JButton("Run Simulation");
		btnRunSimulation.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnRunSimulation.setBounds(192, 420, 203, 29);
		contentPane.add(btnRunSimulation);
		
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnEdit.setEnabled(false);
				btnRunSimulation.setEnabled(false);
				btnSave.setEnabled(true);
				
				txtMirrorNumbers.setEditable(true);
				txtActiveLinks.setEditable(true);
				txtBandwidthConsumption.setEditable(true);
				txtTimetoWrite.setEditable(true);
			}
		});
		btnEdit.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnEdit.setBounds(192, 385, 99, 29);
		contentPane.add(btnEdit);
		
		
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnSave.setEnabled(false);
				btnEdit.setEnabled(true);
				btnRunSimulation.setEnabled(true);
				
				txtMirrorNumbers.setEditable(false);
				txtActiveLinks.setEditable(false);
				txtBandwidthConsumption.setEditable(false);
				txtTimetoWrite.setEditable(false);
				
			}
		});
		
		
		btnRunSimulation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
	}
}
