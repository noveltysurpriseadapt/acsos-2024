package rdm.gui;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import rdm.management.NetworkManagment;



public class GUI extends AnchorPane{
	
	  private XYChart.Series series_bc,threshold_bc;
	  private XYChart.Series series_al,threshold_al;
	  private XYChart.Series series_ttw,threshold_ttw;
	  
	  final NumberAxis xAxis = new NumberAxis();
	  final NumberAxis yAxis = new NumberAxis();
	  
	  private String results_log;
	    
	    
	  
      
	public GUI() {
		
		// TODO Auto-generated constructor stub
		
		
				
		series_bc = new XYChart.Series();
		series_al = new XYChart.Series();
		series_ttw = new XYChart.Series();
		threshold_bc = new XYChart.Series();
		threshold_al = new XYChart.Series();
		threshold_ttw = new XYChart.Series();
		
		results_log="";
		
		

		loadGUI();
		
		
		
		
		
		
	}
	
	public void loadGUI()
	{
				readResultsLog();
				
				
				//Line Chart
				final NumberAxis xAxis = new NumberAxis();
			    final NumberAxis yAxis = new NumberAxis();
			    
			    xAxis.setLabel("Time Steps");
			    yAxis.setLabel("Satisfaction Level");
				LineChart<Number,Number> lineChart = 
		                new LineChart<Number,Number>(xAxis,yAxis);
		                
		       lineChart.setTitle("Bandwidth Consumption");
		      //defining a series
		     
		        series_bc.setName("BandwidthConsumption");
		        threshold_bc.setName("Threshold");
		        
		        //populating the series with data
		      	lineChart.getData().add(series_bc);
		      	lineChart.getData().add(threshold_bc);
                lineChart.setLayoutX(20);
	            lineChart.setLayoutY(20);
	            lineChart.setPrefSize(400, 350);
		      	this.getChildren().add(lineChart);
		      	lineChart.setCreateSymbols(false);
		      	
		      	final NumberAxis xAxis1 = new NumberAxis();
			    final NumberAxis yAxis1 = new NumberAxis();
			    xAxis1.setLabel("Time Steps");
			    yAxis1.setLabel("Satisfaction Level");
				LineChart<Number,Number> lineChart1 = 
		                new LineChart<Number,Number>(xAxis1,yAxis1);
		                
		       lineChart1.setTitle("Active Network Links");
		      //defining a series
		       
		        series_al.setName("Active Network Links");
		        threshold_al.setName("Threshold");
		        
		        //populating the series with data
		      	lineChart1.getData().add(series_al);
		      	lineChart1.getData().add(threshold_al);
		      	lineChart1.setCreateSymbols(false);
                lineChart1.setLayoutX(430);
	            lineChart1.setLayoutY(20);
	            lineChart1.setPrefSize(400, 350);
		      	this.getChildren().add(lineChart1);
		      	
		      	
		      	
		    	final NumberAxis xAxis2 = new NumberAxis();
			    final NumberAxis yAxis2 = new NumberAxis();
			    xAxis2.setLabel("Time Steps");
			    yAxis2.setLabel("Satisfaction Level");
				LineChart<Number,Number> lineChart3 = 
		                new LineChart<Number,Number>(xAxis2,yAxis2);
		                
		       lineChart3.setTitle("Time to Write Data");
		      //defining a series
		       
		        series_ttw.setName("Time to Write Data");
		        threshold_ttw.setName("Threshold");
		        
		        //populating the series with data
		      	lineChart3.getData().add(series_ttw);
		    	lineChart3.getData().add(threshold_ttw);
		    	lineChart3.setCreateSymbols(false);
                lineChart3.setLayoutX(830);
	            lineChart3.setLayoutY(20);
	            lineChart3.setPrefSize(400, 350);
		      	this.getChildren().add(lineChart3);
		      	
		      	Label lblresults=new Label("Results:");
		    	lblresults.setLayoutX(80);
		      	lblresults.setLayoutY(400);
		      	this.getChildren().addAll(lblresults);
		      	TextArea textArea = new TextArea("");
		      	textArea.setLayoutX(80);
		      	textArea.setLayoutY(420);
		      	textArea.setText(results_log);
		      	textArea.setEditable(false);
		        this.getChildren().addAll(textArea);
		        textArea.setPrefSize(1000, 200);
		     
		      	
	}
	
	
	
	public void readResultsLog()
	{
		
		JSONParser parser1 = new JSONParser();
		
		try {
			String path =new File("config_log_files\\log.json").getAbsolutePath();
			
			FileReader fr=new FileReader(path);
			Object obj1 = parser1.parse(fr);

			JSONObject jsonObject = (JSONObject) obj1;
			Set m=jsonObject.keySet();
			System.out.println(m.size());
			
			for(int i=0;i<m.size();i++)
			{
				JSONObject obj=(JSONObject) jsonObject.get(i+"");
				System.out.println("timestep: "+i);
				System.out.println("Selected Topology: "+obj.get("selected_topology"));
				System.out.println("Active Links: "+obj.get("active_links"));
				System.out.println("Bandwidth Consumption: "+obj.get("badwidth_consumption"));
				System.out.println("Time to Write Data"+obj.get("time_to_write")+"\n");
				
				results_log=results_log+"Timestep: "+i+", Selected_Topology: "+obj.get("selected_topology")+", Active_Links: "+obj.get("active_links")+", Bandwidth_Consumption: "+obj.get("badwidth_consumption")+", Time_to_Write_Data: "+obj.get("time_to_write")+"\n";
				
				
				//populating series with data
				 series_bc.getData().add(new XYChart.Data(i,obj.get("badwidth_consumption")));
				 series_al.getData().add(new XYChart.Data(i,obj.get("active_links")));
				 series_ttw.getData().add(new XYChart.Data(i,obj.get("time_to_write")));
				
				 threshold_bc.getData().add(new XYChart.Data(i,NetworkManagment.network_properties.m.getThresholdBandwidthConsumption()));
				 threshold_al.getData().add(new XYChart.Data(i,NetworkManagment.network_properties.m.getThresholdActiveLinks()));
				 threshold_ttw.getData().add(new XYChart.Data(i,NetworkManagment.network_properties.m.getThresholdTimeToWrite()));
				 
			}
			
	}
	catch(FileNotFoundException ex)
	{
		ex.printStackTrace();
	}
	catch(IOException ioex)
	{
		ioex.printStackTrace();
	}
	catch(ParseException ex)
	{
		ex.printStackTrace();
	}

}

	

}
