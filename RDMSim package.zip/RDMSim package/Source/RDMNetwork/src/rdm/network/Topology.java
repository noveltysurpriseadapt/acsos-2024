package rdm.network;

public class Topology {
	
	private String topology_name;
	private double min_active_links;
	private double max_active_links;
	private double min_bandwidth_consumption;
	private double max_bandwidth_consumption;
	private double min_time_to_write;
	private double max_time_to_write;

	
	public Topology()
	{
		topology_name="rt";
	}
	
	public void setTopologyName(String topologyname)
	{
		this.topology_name=topologyname;
	}
	
	public String getTopologyName()
	{
		return this.topology_name;
	}
	
	

	public double getMinActiveLinks() {
		return min_active_links;
	}


	public void setMinActiveLinks(double min_active_links) {
		this.min_active_links = min_active_links;
	}


	public double getMaxActiveLinks() {
		return max_active_links;
	}


	public void setMaxActiveLinks(double max_active_links) {
		this.max_active_links = max_active_links;
	}


	public double getMinBandwidthConsumption() {
		return min_bandwidth_consumption;
	}


	public void setMinBandwidthConsumption(double min_bandwidth_consumption) {
		this.min_bandwidth_consumption = min_bandwidth_consumption;
	}


	public double getMaxBandwidthConsumption() {
		return max_bandwidth_consumption;
	}


	public void setMaxBandwidthConsumption(double max_bandwidth_consumption) {
		this.max_bandwidth_consumption = max_bandwidth_consumption;
	}


	public double getMinTimeToWrite() {
		return min_time_to_write;
	}


	public void setMinTimeToWrite(double min_time_to_write) {
		this.min_time_to_write = min_time_to_write;
	}


	public double getMaxTimeToWrite() {
		return max_time_to_write;
	}


	public void setMaxTimeToWrite(double max_time_to_write) {
		this.max_time_to_write = max_time_to_write;
	}

	
	

}
