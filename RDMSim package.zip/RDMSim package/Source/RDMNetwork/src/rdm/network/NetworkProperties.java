package rdm.network;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import rdm.validation.RDMValidation;

/**
 * 
 * @author Huma Samin
 * Class to set basic properties for RDM Network such as number of mirrors, number of links
 * and current topology.
 *
 */
public class NetworkProperties {
	
	public static int number_of_mirrors;
	public static int number_of_links;
	public static Monitorables m;
	
	//checking topologylist
	public static TopologyList topologylist;
	public static Topology current_topology;
	
	public NetworkProperties() {
		super();
		//number_of_mirrors = nm;
		//number_of_links = (number_of_mirrors*(number_of_mirrors-1)/2);
		m=new Monitorables();
		
		//Checking code
		topologylist=new TopologyList();
	}
	
	
	//checking code
	public void setCurrentTopology(Topology ct)
	{
		current_topology=ct;
		//topologylist.loadTopologyImpacts();
		
	}
	
	public Topology getCurrentTopology()
	{
		return current_topology;
	}
	/**
	 * Method to load the network properties from configuration file
	 */
	public void loadNetworkSettings() 
	{
		JSONParser parser = new JSONParser();
		
		try {
			String path = new File("config_log_files\\configuration.json").getAbsolutePath();
			
			Object obj1 = parser.parse(new FileReader(path));//parsing the JSON string inside the file that we created earlier.

			JSONObject jsonObject = (JSONObject) obj1;
			
			//Step 1: Load the number of mirrors from configuration file
			int mirror_number = Integer.parseInt(jsonObject.get("mirror_number").toString());
			number_of_mirrors=mirror_number;
			//set the number of links on the basis of number of mirrors as a fully connected RDM network
			number_of_links = (number_of_mirrors*(number_of_mirrors-1)/2);
			
			//Step 2: load Topologies			
			topologylist.loadTopologies();
			topologylist.loadTopologyImpacts();
			
		//Step2: load the threshold values for monitorables
			double active_links_threshold = Double.parseDouble(jsonObject.get("link_threshold").toString());
			
			double bandwidth_threshold = Double.parseDouble(jsonObject.get("bandwidth_threshold").toString());
			
			double writing_time_threshold = Double.parseDouble(jsonObject.get("writing_times_threshold").toString());
			
			
			//Validation of threshold values
			try
			{
			if(active_links_threshold<0.0||active_links_threshold>number_of_links)
			{
				
				throw new RDMValidation("invalid_link_threshold");
			}
			if(bandwidth_threshold<0||bandwidth_threshold>number_of_links*30)
			{
				throw new RDMValidation("invalid_bandwidth_threshold");
			}
			if(writing_time_threshold<0||writing_time_threshold>NetworkProperties.number_of_links*20)
			{
				throw new RDMValidation("invalid_writing_time_threshold");
			}
		}catch(RDMValidation va)
		{
			va.validateConfigurationSetup();
		}
			m.setThresholdActiveLinks(active_links_threshold);
			m.setThresholdBandwidthConsumption(bandwidth_threshold);
			m.setThresholdTimeToWrite(writing_time_threshold);
			
			
			
		}
		catch(FileNotFoundException fe)
		{
			fe.printStackTrace();
		}
		catch(IOException ioex)
		{
			ioex.printStackTrace();
		}
		catch(ParseException pe)
		{
			pe.printStackTrace();
		}

	}

}
