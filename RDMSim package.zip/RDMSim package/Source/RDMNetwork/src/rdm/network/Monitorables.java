package rdm.network;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import rdm.simulation.UncertaintyScenario;

/**
 * 
 * Class to define monitorable metrics for the RDM network and randomly generate their values
 * 
 */

public class Monitorables {
	
	private int active_links;
	private double time_to_write;//time to write
	private double bandwidth_consumption;
	
	//thresholds
	private double threshold_active_links;
	
	private double threshold_bandwidth_consumption;
	private double threshold_time_to_write;
	
	
	
	
	
	public int getActiveLinks() {
		return active_links;
	}
	public void setActiveLinks(int active_links) {
		this.active_links = active_links;
	}
	
	public double getTimeToWrite() {
		return time_to_write;
	}
	public void setTimeToWrite(double ttw) {
		this.time_to_write = ttw;
	}
	public double getBandwidthConsumption() {
		return bandwidth_consumption;
	}
	public void setBandwidthConsumption(double bandwidth_consumption) {
		this.bandwidth_consumption = bandwidth_consumption;
	}
	
	public double getThresholdActiveLinks() {
		return threshold_active_links;
	}
	public void setThresholdActiveLinks(double threshold_active_links) {
		this.threshold_active_links = threshold_active_links;
	}
	public double getThresholdBandwidthConsumption() {
		return threshold_bandwidth_consumption;
	}
	public void setThresholdBandwidthConsumption(double threshold_bandwidth_consumption) {
		this.threshold_bandwidth_consumption = threshold_bandwidth_consumption;
	}
	public double getThresholdTimeToWrite() {
		return threshold_time_to_write;
	}
	public void setThresholdTimeToWrite(double threshold_time_to_write) {
		this.threshold_time_to_write = threshold_time_to_write;
	}

	
	//generate monitorables for a single run
	public Monitorables generateMonitorables(String selected_topology,UncertaintyScenario current_scenario)
	{
			
		for(int i=0;i<TopologyList.topologies.size();i++)
		{
			if(TopologyList.topologies.get(i).getTopologyName().equals(selected_topology)&& current_scenario.getCurrentScenario()==0)
			{
				
				double link_dev=0;
				double bandwidth_dev=0;
				double writing_time_dev=0;
				
				double al=ThreadLocalRandom.current().nextDouble(TopologyList.topologies.get(i).getMinActiveLinks(),TopologyList.topologies.get(i).getMaxActiveLinks()+1);
				active_links=(int)(al-((link_dev/100)*al));
				
				int link_bandwidth=(int)ThreadLocalRandom.current().nextDouble(20,30+1);
				double bc=active_links*link_bandwidth;
				//double bc=ThreadLocalRandom.current().nextDouble(TopologyList.topologies.get(i).getMinBandwidthConsumption(),TopologyList.topologies.get(i).getMaxBandwidthConsumption()+1);
				bandwidth_consumption=(bc-((bandwidth_dev/100)*bc));
				int link_time_to_write=(int)ThreadLocalRandom.current().nextDouble(10,20+1);
				double ttw=active_links*link_time_to_write;
				//double ttw=ThreadLocalRandom.current().nextDouble(TopologyList.topologies.get(i).getMinTimeToWrite(),TopologyList.topologies.get(i).getMaxTimeToWrite()+1);
				time_to_write=(ttw-((writing_time_dev/100)*ttw));
				
				
			}
			else
			{
				if(selected_topology.equals("rt")&&current_scenario.getCurrentScenario()!=0)
				{
					
					
					
					double link_dev=ThreadLocalRandom.current().nextDouble(current_scenario.getMinDeviationRTLinks(),current_scenario.getMaxDeviationRTLinks()+1);
					double bandwidth_dev=ThreadLocalRandom.current().nextDouble(current_scenario.getMinDeviationRTBandwidth(),current_scenario.getMaxDeviationRTBandwidth()+1);
					double writing_time_dev=ThreadLocalRandom.current().nextDouble(current_scenario.getMinDeviationRTWritingTime(),current_scenario.getMaxDeviationRTWritingTime()+1);
					
					if(link_dev>0&&link_dev<1)
					{
						link_dev=0;
					}
					if(bandwidth_dev>0&&bandwidth_dev<1)
					{
						bandwidth_dev=0;
					}
					if(writing_time_dev>0&&writing_time_dev<1)
					{
						writing_time_dev=0;
					}
					
					
					double al=ThreadLocalRandom.current().nextDouble(TopologyList.topologies.get(1).getMinActiveLinks(),TopologyList.topologies.get(1).getMaxActiveLinks()+1);
					active_links=(int)(al-((link_dev/100)*al));
					
					int link_bandwidth=(int)ThreadLocalRandom.current().nextDouble(20,30+1);
					
					double bc=active_links*link_bandwidth;
					//double bc=ThreadLocalRandom.current().nextDouble(TopologyList.topologies.get(i).getMinBandwidthConsumption(),TopologyList.topologies.get(i).getMaxBandwidthConsumption()+1);
					bandwidth_consumption=(bc+((bandwidth_dev/100)*bc));
					int link_time_to_write=(int)ThreadLocalRandom.current().nextDouble(10,20+1);
					double ttw=active_links*link_time_to_write;
					//double ttw=ThreadLocalRandom.current().nextDouble(TopologyList.topologies.get(i).getMinTimeToWrite(),TopologyList.topologies.get(i).getMaxTimeToWrite()+1);
					time_to_write=(ttw+((writing_time_dev/100)*ttw));
					
					
				}
				else if(selected_topology.equals("mst")&&current_scenario.getCurrentScenario()!=0) {
					
					
					
					
				
				   double link_dev=ThreadLocalRandom.current().nextDouble(current_scenario.getMinDeviationMSTLinks(),current_scenario.getMaxDeviationMSTLinks()+1);
				   double bandwidth_dev=ThreadLocalRandom.current().nextDouble(current_scenario.getMinDeviationMSTBandwidth(),current_scenario.getMaxDeviationMSTBandwidth()+1);
				   double writing_time_dev=ThreadLocalRandom.current().nextDouble(current_scenario.getMinDeviationMSTWritingTime(),current_scenario.getMaxDeviationMSTWritingTime()+1);
				  
				   if(link_dev>0&&link_dev<1)
					{
						link_dev=0;
					}
					if(bandwidth_dev>0&&bandwidth_dev<1)
					{
						bandwidth_dev=0;
					}
					if(writing_time_dev>0&&writing_time_dev<1)
					{
						writing_time_dev=0;
					}
				   
				  
				   
				   double al=ThreadLocalRandom.current().nextDouble(TopologyList.topologies.get(0).getMinActiveLinks(),TopologyList.topologies.get(0).getMaxActiveLinks()+1);
				   active_links=(int)(al-((link_dev/100)*al));
				   //System.out.println("active links without dev: "+al);
				   //System.out.println("link_dev: "+link_dev);
				  // System.out.println("i: "+i);
				  // System.out.println("active links: "+active_links);
				   
				   int link_bandwidth=(int)ThreadLocalRandom.current().nextDouble(20,30+1);
					double bc=active_links*link_bandwidth;
				  // double bc=ThreadLocalRandom.current().nextDouble(TopologyList.topologies.get(i).getMinBandwidthConsumption(),TopologyList.topologies.get(i).getMaxBandwidthConsumption()+1);
				   bandwidth_consumption=(bc+((bandwidth_dev/100)*bc));
				   int link_time_to_write=(int)ThreadLocalRandom.current().nextDouble(10,20+1);
					double ttw=active_links*link_time_to_write;
				   //double ttw=ThreadLocalRandom.current().nextDouble(TopologyList.topologies.get(i).getMinTimeToWrite(),TopologyList.topologies.get(i).getMaxTimeToWrite()+1);
				   time_to_write=(ttw+((writing_time_dev/100)*ttw));
				   

				  				
				}
				
			}
		}
		
		return this;
		
		
	}
	
	

}
