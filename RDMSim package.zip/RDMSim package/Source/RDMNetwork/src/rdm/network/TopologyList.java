package rdm.network;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import rdm.simulation.SimulationProperties;
import rdm.simulation.UncertaintyScenario;
import rdm.validation.RDMValidation;

public class TopologyList {
	
	public static ArrayList<Topology> topologies;
	
	
	public TopologyList()
	{
		topologies=new ArrayList<Topology>();
	}
	
	public void addTopology(Topology t)
	{
		topologies.add(t);
	}
	
	public void removeTopology(Topology t)
	{
		for(int i=0;i<topologies.size();i++)
		{
			if(topologies.get(i).equals(t))
			{
				topologies.remove(i);
			}
		}
	}
	
	public Topology getTopology(Topology t)
	{
		for(int i=0;i<topologies.size();i++)
		{
			if(topologies.get(i).equals(t))
			{
				return topologies.get(i);
			}
		}
		return null;
		
	}
	
	public void loadTopologies()
	{
		JSONParser parser = new JSONParser();
		
		try {
			String path = new File("config_log_files/configuration.json").getAbsolutePath();
			
			Object obj1 = parser.parse(new FileReader(path));//parsing the JSON string inside the file that we created earlier.

			JSONObject jsonObject = (JSONObject) obj1;
			
			
			JSONArray topologylist = (JSONArray) jsonObject.get("topologies");
			
			for(int i=0;i<topologylist.size();i++)
			{
				Topology t=new Topology();
				t.setTopologyName(topologylist.get(i).toString());
				topologies.add(t);
				
			}
			
				
			
		}
		catch(FileNotFoundException fe)
		{
			fe.printStackTrace();
		}
		catch(IOException ioex)
		{
			ioex.printStackTrace();
		}
		catch(ParseException pe)
		{
			pe.printStackTrace();
		}


		
	}
	
	public void loadTopologyImpacts()
	{
		JSONParser parser = new JSONParser();
		
		try {
			String path = new File("config_log_files/configuration.json").getAbsolutePath();
			
			Object obj1 = parser.parse(new FileReader(path));//parsing the JSON string inside the file that we created earlier.

			for(int i=0;i<topologies.size();i++)
			{
				JSONObject jsonObject = (JSONObject) obj1;
			
			
				JSONArray t_active_links = (JSONArray) jsonObject.get(topologies.get(i).getTopologyName()+"_active_links");
			
				int min=((int) Integer.parseInt(t_active_links.get(0).toString()));
				int max=((int) Integer.parseInt(t_active_links.get(1).toString()));
				
				
				try
				{
					if(min<0||min>100||min>=max)
					{
						throw new RDMValidation("invalid_range_links");
					}
					else if(max<0||max>100||min>=max)
					{
						throw new RDMValidation("invalid_range_links");
					}
					
				
				}
				catch(RDMValidation va)
				{
					va.validateConfigurationSetup();
				}
				
			
				
				
				
				
				
				
				topologies.get(i).setMinActiveLinks((NetworkProperties.number_of_links*(int) Integer.parseInt(t_active_links.get(0).toString())/100));
				topologies.get(i).setMaxActiveLinks((NetworkProperties.number_of_links*(int) Integer.parseInt(t_active_links.get(1).toString())/100));
				//System.out.println(topologies.get(i).getMinActiveLinks());
				//System.out.println(topologies.get(i).getMaxActiveLinks());
				
				int link_bandwidth=(int)ThreadLocalRandom.current().nextDouble(20,30+1);
				topologies.get(i).setMinBandwidthConsumption(topologies.get(i).getMinActiveLinks()*link_bandwidth);
				topologies.get(i).setMaxBandwidthConsumption(topologies.get(i).getMaxActiveLinks()*link_bandwidth);
				//System.out.println(link_bandwidth);
				//System.out.println(topologies.get(i).getMinBandwidthConsumption());
				//System.out.println(topologies.get(i).getMaxBandwidthConsumption());
				
				
				int link_time_to_write=(int)ThreadLocalRandom.current().nextDouble(10,20+1);
				
				topologies.get(i).setMinTimeToWrite(topologies.get(i).getMinActiveLinks()*link_time_to_write);
				topologies.get(i).setMaxTimeToWrite(topologies.get(i).getMaxActiveLinks()*link_time_to_write);
				
				
				/*System.out.println(topologies.get(i).getMinBandwidthConsumption());
				System.out.println(topologies.get(i).getMaxBandwidthConsumption());
				System.out.println(topologies.get(i).getMinTimeToWrite());				
				System.out.println(topologies.get(i).getMaxTimeToWrite());*/
				
					}	
			
			
			
		}
		catch(FileNotFoundException fe)
		{
			fe.printStackTrace();
		}
		catch(IOException ioex)
		{
			ioex.printStackTrace();
		}
		catch(ParseException pe)
		{
			pe.printStackTrace();
		}


		
		

	}
}
