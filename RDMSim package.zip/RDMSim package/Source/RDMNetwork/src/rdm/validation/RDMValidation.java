package rdm.validation;

import javax.swing.JOptionPane;

import rdm.network.NetworkProperties;

public class RDMValidation extends Exception{
	
	private String exception_type;
	
	public RDMValidation(String exception_type)
	{
		this.exception_type=exception_type;
		validateConfigurationSetup();
		
	}
	
	public void validateConfigurationSetup()
	{
		if(exception_type.equals("invalid_link_threshold"))
		{
			validateThresholdActiveLinks();
		}
		else if(exception_type.equals("invalid_bandwidth_threshold"))
		{
			validateThresholdBandwidthConsumption();
			
		}
		else if(exception_type.equals("invalid_writing_time_threshold"))
		{
			validateThresholdTimeToWrite();
		}
		else if(exception_type.equals("mst_active_links"))
		{
			validateMSTActiveLinks();
		}
		else if(exception_type.equals("rt_active_links"))
		{
			validateRTActiveLinks();
		}
		else if(exception_type.equals("invalid_scenario"))
		{
			validateScenarioNumber();
		}
		else if(exception_type.equals("invalid_dev_range_links_mst"))
		{
			validateDeviationRangeLinksMST();
		}
		else if(exception_type.equals("invalid_dev_range_bandwidth_mst"))
		{
			validateDeviationRangeBandwidthMST();
		}
		else if(exception_type.equals("invalid_dev_range_ttw_mst"))
		{
			validateDeviationRangeTTWMST();
		}
		else if(exception_type.equals("invalid_dev_range_links_rt"))
		{
			validateDeviationRangeLinksRT();
		}
		else if(exception_type.equals("invalid_dev_range_bandwidth_rt"))
		{
			validateDeviationRangeBandwidthRT();
		}
		else if(exception_type.equals("invalid_dev_range_ttw_rt"))
		{
			validateDeviationRangeTTWRT();
		}
		
	}
	
	public void validateThresholdActiveLinks()
	{
			
		JOptionPane.showMessageDialog(null, "The active links threshold should be between 0 and "+NetworkProperties.number_of_links);
		System.exit(0);	
	}
	
	public void validateThresholdBandwidthConsumption()
	{
		JOptionPane.showMessageDialog(null, "The bandwidth consumption threshold should be between 0 and "+NetworkProperties.number_of_links*30);
		System.exit(0);	
		
	}
	
	public void validateThresholdTimeToWrite()
	{
		JOptionPane.showMessageDialog(null, "The Time to Write threshold should be between 0 and "+NetworkProperties.number_of_links*20);
		System.exit(0);	
		
	}
	
	public void validateMSTActiveLinks()
	{
		JOptionPane.showMessageDialog(null, "The range for active links for MST topology should be between 0 and "+NetworkProperties.number_of_links);
		System.exit(0);	
	}
	
	public void validateRTActiveLinks()
	{
		JOptionPane.showMessageDialog(null, "The range for active links for RT topology should be between 0 and "+NetworkProperties.number_of_links);
		System.exit(0);	
	}
	
	public void validateScenarioNumber()
	{

		JOptionPane.showMessageDialog(null, "The current_scenario should be between 0 and 6");
		System.exit(0);	
		
	}
	
	public void validateDeviationRangeLinksMST() {
		JOptionPane.showMessageDialog(null, "The deviation range for Writing Time should be between 0 to 100 percent and minimum deviation should be less than maximum deviation");
		System.exit(0);
	}
	
	public void validateDeviationRangeBandwidthMST() {
		JOptionPane.showMessageDialog(null, "The deviation range for Writing Time should be between 0 to 100 percent and minimum deviation should be less than maximum deviation");
		System.exit(0);
	}
	
	public void validateDeviationRangeTTWMST() {
		JOptionPane.showMessageDialog(null, "The deviation range for Writing Time should be between 0 to 100 percent and minimum deviation should be less than maximum deviation");
		System.exit(0);
	}
	
	
	public void validateDeviationRangeLinksRT() {
		JOptionPane.showMessageDialog(null, "The deviation range for Writing Time should be between 0 to 100 percent and minimum deviation should be less than maximum deviation");
		System.exit(0);
	}
	
	public void validateDeviationRangeBandwidthRT() {
		JOptionPane.showMessageDialog(null, "The deviation range for Writing Time should be between 0 to 100 percent and minimum deviation should be less than maximum deviation");
		System.exit(0);
	}
	
	public void validateDeviationRangeTTWRT() {
		JOptionPane.showMessageDialog(null, "The deviation range for Writing Time should be between 0 to 100 percent and minimum deviation should be less than maximum deviation");
		System.exit(0);	
	}


}
